document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('exportPdfButton')?.addEventListener('click', () => {

        console.log('Exportando historial a PDF...');
    });
});
