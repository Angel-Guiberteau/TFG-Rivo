<?php

namespace App\Validations;

class ApiValidator extends Validator {

    protected static function rulesValidateId(): array {
        return [
            'id' => 'required|integer',
        ];
    }

    protected static function messagesValidateId(): array {
        return [
            'id.required' => 'Ha sucedido un error inesperado.',
            'id.integer' => 'Tipo de dato no reconocido.',
        ];
    }

    protected static function rulesIncomeOperations(): array {
        return [
            'offset' => 'required|integer',
            'limit' => 'sometimes|integer',
        ];
    }

    protected static function messagesIncomeOperations(): array {
        return [
            'offset.required' => 'El offset es necesario. Pongase en contacto con el equipo de soporte.',
            'offset.integer' => 'Ha sucedido un error inesperado. Pongase en contacto con el equipo de soporte.',
        ];
    }
}
