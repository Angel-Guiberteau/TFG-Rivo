<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * Controlador reservado para futuras operaciones relacionadas con
 * las cuentas de usuario.
 *
 * Actualmente no implementa ningún método.
 *
 * @package App\Http\Controllers
 */
class UsersAccountController extends Controller
{
    //
}
