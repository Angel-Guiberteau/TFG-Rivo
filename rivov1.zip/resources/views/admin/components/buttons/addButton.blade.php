<button class="btn btn-add btn-md mb-2 mt-3" {!! $data ?? ' ' !!} {!! isset($onclick) ? 'onclick="'.$onclick.'"' : '' !!}>
    <i class="fa-solid fa-plus"></i>
</button>