<nav class="mobile-nav">
    <div id="fab-container">
        <button id="fab-toggle" class="fab-option fab-active">
            <i id="fab-icon" class="fas fa-home" data-id="home"></i>
        </button>
        <div id="fab-menu" class="fab-menu"></div>
    </div>
</nav>






