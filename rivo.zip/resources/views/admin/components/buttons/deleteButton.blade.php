<button class="btn btn-danger btn-sm" {!! $data ?? ' ' !!} {!! isset($onclick) ? 'onclick="'.$onclick.'"' : '' !!}>
    <i class="fa-solid fa-trash"></i>
</button>