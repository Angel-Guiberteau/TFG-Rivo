<button class="btn btn-preView btn-sm" {!! $data ?? ' ' !!} {!! isset($onclick) ? 'onclick="'.$onclick.'"' : '' !!}>
    <i class="fa-solid fa-eye"></i>
</button>