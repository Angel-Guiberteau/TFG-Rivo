<button class="btn btn-edit btn-sm" {!! $data ?? '' !!} {!! isset($onclick) ? 'onclick="'.$onclick.'"' : '' !!}>
    <i class="fa-solid fa-pen-to-square"></i>
</button>
