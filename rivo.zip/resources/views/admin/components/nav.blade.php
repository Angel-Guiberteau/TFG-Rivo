<nav class="d-flex align-items-center">
    <div class="d-flex flex-row justify-content-center align-items-center">
        <img id="asideLogo" src="{{ asset('img/logos/whiteRivoPng.png') }}" alt="">
        <h1 class="fs-2 mb-0 align-self-end">Rivo</h1>
    </div>
</nav>