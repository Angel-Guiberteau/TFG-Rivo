<div class="d-flex align-items-center w-100 gap-2 mb-4 mt-4 progress-line-container">
    <a class="step fs-6 active" id="stepInfo">Datos personales</a>
    <div class="progress-line"></div>
    <a class="step fs-6" id="stepCreation">Categorias personales</a>
    <div class="progress-line"></div>
    <a class="step fs-6" id="stepPreview" >Cuentas personales</a>
    <div class="progress-line"></div>
    <a class="step fs-6" id="stepObjetives" >Objetivos del usuario</a>
</div>