@section('projectCSS')

    <link href="{{ asset('css/common.css') }}" rel="stylesheet"/>

    {{-- <link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" rel="stylesheet"/> --}}
    
    {{-- <link rel="stylesheet" href="{{ asset('css/bootstrap-datepicker/bootstrap-datepicker.min.css') }}"> --}}
    
@endsection
