<button type="button" onclick="previousStep({{ $step }})" class="login-btn login-btn-2 w-100 fs-4 fw-bold mb-4">
        Atrás
</button>