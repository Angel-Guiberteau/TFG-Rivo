<div class="d-flex flex-column flex-lg-row w-100 justify-between gap-lg-4">
    @include('components.buttons.previusStepInitialSetup', ['step' => $step])
    @include('components.buttons.initialSetupButton', ['step' => $step])
</div>