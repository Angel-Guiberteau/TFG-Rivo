<div class="showObjectiveButton col-12 col-lg-6 mt-3 mt-lg-4">
    <div class="w-100 info-container newObjective py-4 px-3">
        <div class="d-flex flex-row justify-content-start align-items-center">
            <div class="d-flex flex-column align-items-start gap-0">
                <h3 class="mb-1 fs-4 fw-bold">Añadir un nuevo objetivo</h3>
            </div>
        </div>
    </div>
</div>
