<nav class="navbar bg-dark py-2 px-3 shadow-sm">
    <a href="/admin" class="navbar-brand d-flex align-items-center">
        <img src="{{ asset('img/logos/whiteRivoPng.png') }}" id="logoRivo" alt="Logo" style="height: 40px;">
    </a>
</nav>
