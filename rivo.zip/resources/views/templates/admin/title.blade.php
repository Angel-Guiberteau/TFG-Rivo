<div class="bg-gradient-primary text-white py-3 px-4 rounded shadow-sm d-flex align-items-center">
    <h1 class="fw-semibold fs-4 mb-0">{{ $title }}</h1>
</div>
