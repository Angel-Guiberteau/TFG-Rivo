<?php

return [
    'reset'     => 'Tu contraseña ha sido restablecida.',
    'sent'      => 'Te hemos enviado por correo el enlace para restablecer tu contraseña.',
    'throttled' => 'Por favor espera antes de volver a intentarlo.',
    'token'     => 'Este token de restablecimiento de contraseña es inválido.',
    'user'      => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
];
