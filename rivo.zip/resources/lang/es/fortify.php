<?php

return [
    'two_factor_authentication' => 'Autenticación en dos pasos',
    'confirm_password' => 'Confirma tu contraseña antes de continuar.',
    'failed' => 'Estas credenciales no coinciden con nuestros registros.',
    'password' => 'La contraseña proporcionada es incorrecta.',
    'throttle' => 'Demasiados intentos. Por favor intenta de nuevo en :seconds segundos.',
];
