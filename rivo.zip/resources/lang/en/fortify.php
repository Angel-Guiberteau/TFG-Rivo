<?php

return [
    'two_factor_authentication' => 'Two-Factor Authentication',
    'confirm_password' => 'Please confirm your password before continuing.',
    'failed' => 'These credentials do not match our records.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Too many attempts. Please try again in :seconds seconds.',
];
