<!DOCTYPE html>
<html lang="es">
    <head>
        <?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <link href="<?php echo e(asset('css/common.css')); ?>" rel="stylesheet"/>

    </head>
    <body>
        <div id="loader">
            <img src="<?php echo e(asset('img/logos/whiteRivoPng.png')); ?>" class="loader-logo" />
        </div>

        <?php echo $__env->yieldContent('content'); ?>
        <script>
            const loader = document.getElementById('loader');
            let loaderVisible = false;
            let loaderTimeout;
        
            const hideLoader = () => {
                clearTimeout(loaderTimeout);
                if (loaderVisible) {
                    loader.style.animation = 'fadeOut 0.6s ease-in-out forwards';
                    setTimeout(() => loader.remove(), 600);
                }
            };
        
            loaderTimeout = setTimeout(() => {
                loader.style.display = 'flex';
                loaderVisible = true;
        
                if (document.readyState === 'complete') {
                    hideLoader();
                }
            }, 1500);
        
            if (document.readyState !== 'complete') {
                window.addEventListener('load', hideLoader);
            } else {
                hideLoader();
            }
        </script>
        
        
    </body>
</html><?php /**PATH C:\htdocs\TFG-Rivo\resources\views/layout.blade.php ENDPATH**/ ?>