<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.ico')); ?>">

<title> <?php echo $__env->yieldContent('title'); ?> </title>

<link href="<?php echo e(asset('css/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('css/datatable/datatables.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('css/fontAwesome/fontawesome.min.css')); ?>" rel="stylesheet"/>

<?php echo $__env->yieldPushContent('styles'); ?>

<?php echo $__env->make('projectCSS', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script src="<?php echo e(asset('js/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatable/datatables.min.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>

<?php echo $__env->make('projectJS', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\htdocs\TFG-Rivo\resources\views/header.blade.php ENDPATH**/ ?>