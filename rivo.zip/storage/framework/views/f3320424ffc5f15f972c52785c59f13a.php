<div class="col-12 movement-block mt-3 mt-lg-4 py-4 px-4">
    <h3 class="section-title">Movimientos recientes</h3>
    <div id="recentOperations" class="row">
        <?php $__currentLoopData = $sixOperations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-lg-6 <?php echo e($index % 2 === 0 ? 'border-lg-end' : ''); ?>">
                <div class="movement-item">
                    <div class="movement-row" data-id="<?php echo e($operation->id); ?>">
                        <div class="movement-left d-flex align-items-center gap-3">
                            <div class="movement-icon">
                                <?php echo $operation->category->icon->icon; ?>

                            </div>
                            <div class="movement-info">
                                <p class="movement-date mb-0">
                                    <?php echo e(\Carbon\Carbon::parse($operation->action_date)->locale('es')->translatedFormat('j M')); ?>

                                </p>
                                <p class="badge mb-1 
                                    <?php echo e($operation->movement_type_id == 1 ? 'badge-income' : 
                                    ($operation->movement_type_id == 2 ? 'badge-expense' : 
                                    ($operation->movement_type_id == 3 ? 'badge-save' : '') )); ?>">
                                    <?php echo e($operation->movement_type_id == 1 ? 'Ingreso' : 
                                    ($operation->movement_type_id == 2 ? 'Gasto' : 
                                    ($operation->movement_type_id == 3 ? 'Ahorro' : '') )); ?>

                                </p>
                                <p class="movement-name mb-0"><?php echo e($operation->category->name); ?></p>
                            </div>
                        </div>
                        <div class="movement-right">
                            <p class="movement-amount m-0 fs-5 <?php echo e($operation->movement_type_id == 2 ? 'negative' : 'positive'); ?>">
                                <?php echo e($operation->movement_type_id == 2 ? '-' : '+'); ?><?php echo e(number_format($operation->amount, 2)); ?>€
                            </p>
                        </div>
                    </div>
                </div>
                

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\htdocs\TFG-Rivo\resources\views/templates/home/recentMovements.blade.php ENDPATH**/ ?>