<?php $__env->startSection('projectCSS'); ?>

    <link href="<?php echo e(asset('css/common.css')); ?>" rel="stylesheet"/>

    
    
    
    
<?php $__env->stopSection(); ?>
<?php /**PATH C:\htdocs\TFG-Rivo\resources\views/projectCSS.blade.php ENDPATH**/ ?>