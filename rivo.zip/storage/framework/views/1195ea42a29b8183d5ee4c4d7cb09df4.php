<?php $__env->startSection('projectJS'); ?>
    
    

    

    

<?php $__env->stopSection(); ?><?php /**PATH C:\htdocs\TFG-Rivo\resources\views/projectJS.blade.php ENDPATH**/ ?>