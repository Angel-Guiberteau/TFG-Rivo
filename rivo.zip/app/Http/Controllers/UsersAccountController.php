<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersAccountController extends Controller
{
    //
}
