<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * Controlador ProgrammedController
 *
 * Controlador reservado para gestionar operaciones programadas.
 * Actualmente no implementa ningún método.
 */
class ProgrammedController extends Controller
{
    // Métodos pendientes de implementación
}
