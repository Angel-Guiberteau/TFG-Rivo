<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * Controlador RoleController
 *
 * Controlador reservado para gestionar los roles del sistema.
 * Actualmente no contiene métodos implementados.
 */
class RoleController extends Controller
{
    // Métodos pendientes de implementación
}
