<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * Controlador UserCategoryController
 *
 * Controlador reservado para gestionar las categorías personalizadas de usuario.
 * Actualmente no contiene métodos implementados.
 */
class UserCategoryController extends Controller
{
    // Métodos pendientes de implementación
}
