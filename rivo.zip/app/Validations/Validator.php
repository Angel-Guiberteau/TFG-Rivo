<?php

namespace App\Validations;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator as LaravelValidator;

abstract class Validator extends Controller
{
    public static function validate(array $data, string $option): array {
        $rules = static::getRules($option);
        $messages = static::getMessages($option);

        $validator = LaravelValidator::make($data, $rules, $messages);

        if ($validator->fails()) {
            return [
                'status' => false,
                'error' => $validator->errors()->all(),
            ];
        }

        return [
            'status' => true,
            'data' => $validator->validated(),
        ];
    }

    private static function getRules(string $option): array {
        return match ($option) {
            'add' => static::rulesAdd(),
            'edit' => static::rulesEdit(),
            'delete' => static::rulesDelete(),
            'initialSetup' => static::rulesInitialSetup(),
            'updatePersonalCategories' => static::rulesUpdatePersonalCategories(),
            'updatePersonalAccounts' => static::rulesUpdatePersonalAccounts(),
            'addIncomeUser' => static::rulesAddOperationUser(),
            'getOperationById' => static::rulesGetOperationById(),
            'incomeOperations' => static::rulesIncomeOperations(),
            'deleteOperation' => static::rulesDeleteOperation(),
            default => [],
        };
    }

    private static function getMessages(string $option): array {
        return match ($option) {
            'add' => static::messagesAdd(),
            'edit' => static::messagesEdit(),
            'delete' => static::messagesDelete(),
            'initialSetup' => static::messagesInitialSetup(),
            'updatePersonalCategories' => static::messagesUpdatePersonalCategories(),
            'updatePersonalAccounts' => static::messagesUpdatePersonalAccounts(),
            'addIncomeUser' => static::messagesAddOperationUser(),
            'getOperationById' => static::messagesGetOperationById(),
            'incomeOperations' => static::messagesIncomeOperations(),
            'deleteOperation' => static::messagesDeleteOperation(),
            default => [],
        };
    }

    protected static function rulesAdd(): array { return []; }
    protected static function messagesAdd(): array { return []; }
    protected static function rulesEdit(): array { return []; }
    protected static function messagesEdit(): array { return []; }
    protected static function rulesDelete(): array { return []; }
    protected static function messagesDelete(): array { return []; }
    protected static function rulesInitialSetup(): array { return []; }
    protected static function messagesInitialSetup(): array { return []; }
    protected static function rulesUpdatePersonalCategories(): array { return []; }
    protected static function messagesUpdatePersonalCategories(): array { return []; }
    protected static function rulesUpdatePersonalAccounts(): array { return []; }
    protected static function messagesUpdatePersonalAccounts(): array { return []; }
    protected static function rulesAddOperationUser(): array { return []; }
    protected static function messagesAddOperationUser(): array { return []; }
    protected static function rulesGetOperationById(): array { return []; }
    protected static function messagesGetOperationById(): array { return []; }
    protected static function rulesIncomeOperations(): array { return []; }
    protected static function messagesIncomeOperations(): array { return []; }
    protected static function rulesDeleteOperation(): array { return []; }
    protected static function messagesDeleteOperation(): array { return []; }
}
