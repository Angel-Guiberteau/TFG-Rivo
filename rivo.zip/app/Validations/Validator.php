<?php

namespace App\Validations;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator as LaravelValidator;

abstract class Validator extends Controller
{
    public static function validate(array $data, string $option): array {
        $rules = static::getRules($option);
        $messages = static::getMessages($option);

        $validator = LaravelValidator::make($data, $rules, $messages);

        if ($validator->fails()) {
            return [
                'status' => false,
                'error' => $validator->errors()->all(),
            ];
        }

        return [
            'status' => true,
            'data' => $validator->validated(),
        ];
    }

    private static function getRules(string $option): array {
        return match ($option) {
            'add' => static::rulesAdd(),
            'edit' => static::rulesEdit(),
            'delete' => static::rulesDelete(),
            'initialSetup' => static::rulesInitialSetup(),
            'updatePersonalCategories' => static::rulesUpdatePersonalCategories(),
            'updatePersonalAccounts' => static::rulesUpdatePersonalAccounts(),
            'addIncomeUser' => static::rulesAddOperationUser(),
            'validateIdOnly' => static::rulesValidateId(),
            'incomeOperations' => static::rulesIncomeOperations(),
            'updatePersonalObjetives' => static::rulesUpdatePersonalObjetives(),
        };
    }

    private static function getMessages(string $option): array {
        return match ($option) {
            'add' => static::messagesAdd(),
            'edit' => static::messagesEdit(),
            'delete' => static::messagesDelete(),
            'initialSetup' => static::messagesInitialSetup(),
            'updatePersonalCategories' => static::messagesUpdatePersonalCategories(),
            'updatePersonalAccounts' => static::messagesUpdatePersonalAccounts(),
            'addIncomeUser' => static::messagesAddOperationUser(),
            'validateIdOnly' => static::messagesValidateId(),
            'incomeOperations' => static::messagesIncomeOperations()
            ,'updatePersonalObjetives' => static::messagesUpdatePersonalObjetives(),
            default => [],
        };
    }

    protected static function rulesAdd(): array { return []; }
    protected static function messagesAdd(): array { return []; }
    protected static function rulesEdit(): array { return []; }
    protected static function messagesEdit(): array { return []; }
    protected static function rulesDelete(): array { return []; }
    protected static function messagesDelete(): array { return []; }
    protected static function rulesInitialSetup(): array { return []; }
    protected static function messagesInitialSetup(): array { return []; }
    protected static function rulesUpdatePersonalCategories(): array { return []; }
    protected static function messagesUpdatePersonalCategories(): array { return []; }
    protected static function rulesUpdatePersonalAccounts(): array { return []; }
    protected static function messagesUpdatePersonalAccounts(): array { return []; }
    protected static function rulesAddOperationUser(): array { return []; }
    protected static function messagesAddOperationUser(): array { return []; }
    protected static function rulesValidateId(): array { return []; }
    protected static function messagesValidateId(): array { return []; }
    protected static function rulesIncomeOperations(): array { return []; }
    protected static function messagesIncomeOperations(): array { return []; }
    protected static function rulesUpdatePersonalObjetives(): array { return []; }
    protected static function messagesUpdatePersonalObjetives(): array { return [];}
}
